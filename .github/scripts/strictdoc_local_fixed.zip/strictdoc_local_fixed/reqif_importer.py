import xml.etree.ElementTree as ET

class ReqIFImporter:
    def __init__(self, file_path):
        self.file_path = file_path

    def parse(self):
        tree = ET.parse(self.file_path)
        root = tree.getroot()
        namespace = {'reqif': 'http://www.omg.org/spec/ReqIF/20110401/reqif.xsd'}

        requirements = []
        for spec_object in root.findall('.//reqif:SPEC-OBJECT', namespace):
            req_id = spec_object.get('IDENTIFIER', 'UNKNOWN_ID')
            title = ''
            description = ''

            for value in spec_object.findall('.//reqif:ATTRIBUTE-VALUE-STRING', namespace):
                value_text = value.find('reqif:THE-VALUE', namespace)
                if value_text is not None and value_text.text:
                    text = value_text.text.strip()
                    if not title:
                        title = text
                    else:
                        description += text + '\n'

            requirements.append({
                'id': req_id,
                'title': title or 'Untitled Requirement',
                'description': description.strip()
            })
        return requirements
