"""
reqif_importer.py
-----------------
Lightweight, dependency-free ReqIF parser
Compatible with EA, DOORS, Polarion, Jama, and PTC ReqIF dialects.
Mimics the 'reqif' library interface but runs standalone.
"""

import xml.etree.ElementTree as ET

# Default ReqIF namespaces (auto-extended during parsing)
REQIF_NS = {
    'reqif': 'http://www.omg.org/spec/ReqIF/20110401/reqif.xsd',
    'xhtml': 'http://www.w3.org/1999/xhtml'
}

# --------------------------------------------------------------------
# Core lightweight ReqIF classes
# --------------------------------------------------------------------

class AttributeValue:
    """Represents a single ReqIF attribute value (STRING, XHTML, ENUM, etc.)."""
    def __init__(self, definition_ref=None, value=None):
        self.definition_ref = definition_ref
        self.value = value


class SpecObject:
    """Represents one <SPEC-OBJECT> in ReqIF."""
    def __init__(self, identifier=None, long_name=None, type_ref=None):
        self.identifier = identifier
        self.long_name = long_name
        self.type_ref = type_ref
        self.values = []

    def get_text_value(self):
        """Combine all string/xhtml values into one long text."""
        parts = []
        for val in self.values:
            if val.value:
                parts.append(val.value.strip())
        return "\n".join(parts)


# --------------------------------------------------------------------
# Main importer class
# --------------------------------------------------------------------

class ReqIFImporter:
    """
    Parses a ReqIF file into a simplified list of requirements:
        [{id, title, description}, ...]
    """

    def __init__(self, file_path):
        self.file_path = file_path
        self.ns = dict(REQIF_NS)  # copy default namespaces

    def _detect_namespaces(self, root):
        """Auto-detect any additional namespaces used in the ReqIF file."""
        for k, v in root.attrib.items():
            if k.startswith("xmlns:"):
                prefix = k.split(":", 1)[1]
                self.ns[prefix] = v

    def _get_text_from_xhtml(self, elem):
        """Extracts readable text from XHTML blocks (ignoring markup)."""
        if elem is None:
            return ""
        return "".join(elem.itertext()).strip()

    def parse(self):
        tree = ET.parse(self.file_path)
        root = tree.getroot()
        self._detect_namespaces(root)

        spec_objects = []
        for so_elem in root.findall('.//reqif:SPEC-OBJECT', self.ns):
            so = SpecObject(
                identifier=so_elem.get('IDENTIFIER'),
                long_name=so_elem.get('LONG-NAME'),
                type_ref=so_elem.get('TYPE')
            )

            # -------------------------------
            # Extract STRING values
            # -------------------------------
            for attr_val in so_elem.findall('.//reqif:ATTRIBUTE-VALUE-STRING', self.ns):
                val = attr_val.find('reqif:THE-VALUE', self.ns)
                if val is not None and val.text:
                    so.values.append(AttributeValue('STRING', val.text.strip()))

            # -------------------------------
            # Extract XHTML values
            # -------------------------------
            for attr_val in so_elem.findall('.//reqif:ATTRIBUTE-VALUE-XHTML', self.ns):
                xhtml_block = attr_val.find('.//xhtml:div', self.ns)
                if xhtml_block is not None:
                    text_content = self._get_text_from_xhtml(xhtml_block)
                    so.values.append(AttributeValue('XHTML', text_content))

            # -------------------------------
            # Extract ENUMERATION values
            # -------------------------------
            for attr_val in so_elem.findall('.//reqif:ATTRIBUTE-VALUE-ENUMERATION', self.ns):
                enum_refs = [v.get('REF') for v in attr_val.findall('.//reqif:ENUM-VALUE-REF', self.ns)]
                if enum_refs:
                    so.values.append(AttributeValue('ENUM', ', '.join(enum_refs)))

            # -------------------------------
            # Extract EA or DOORS custom fields (AD_TITLE, AD_DESC, etc.)
            # -------------------------------
            for attr_val in so_elem.findall('.//reqif:ATTRIBUTE-VALUE-STRING', self.ns):
                def_ref = attr_val.find('reqif:ATTRIBUTE-DEFINITION-STRING-REF', self.ns)
                the_val = attr_val.find('reqif:THE-VALUE', self.ns)
                if def_ref is not None and the_val is not None and the_val.text:
                    ref_name = def_ref.text.strip().upper()
                    if any(k in ref_name for k in ['TITLE', 'AD_TITLE']):
                        so.values.append(AttributeValue('TITLE', the_val.text.strip()))
                    elif any(k in ref_name for k in ['DESC', 'DESCRIPTION', 'AD_DESC']):
                        so.values.append(AttributeValue('DESC', the_val.text.strip()))

            spec_objects.append(so)

        # ----------------------------------------------------------------
        # Convert to simplified requirement dicts
        # ----------------------------------------------------------------
        requirements = []
        for so in spec_objects:
            req_id = so.identifier or "UNKNOWN_ID"

            # Gather all string/xhtml/enum values
            text_values = [v.value for v in so.values if v.definition_ref in ('STRING', 'XHTML')]
            enum_values = [v.value for v in so.values if v.definition_ref == 'ENUM']

            # EA/DOORS explicit titles/descriptions
            title_values = [v.value for v in so.values if v.definition_ref == 'TITLE']
            desc_values = [v.value for v in so.values if v.definition_ref == 'DESC']

            title = title_values[0] if title_values else (so.long_name or (text_values[0] if text_values else "Untitled Requirement"))
            description = ""

            if desc_values:
                description = "\n".join(desc_values)
            elif len(text_values) > 1:
                description = "\n".join(text_values[1:])
            elif not description and text_values:
                description = text_values[0]

            if enum_values:
                description += "\n\nEnum: " + ", ".join(enum_values)

            requirements.append({
                'id': req_id,
                'title': title.strip(),
                'description': description.strip() or "(No description found)"
            })

        return requirements

