"""
reqif_importer.py
-----------------
Lightweight, dependency-free ReqIF parser.
Compatible with EA, DOORS, Polarion, Jama, and PTC ReqIF dialects.
Mimics the 'reqif' library interface but runs standalone.
"""

import xml.etree.ElementTree as ET

# Default ReqIF namespaces (auto-extended during parsing)
REQIF_NS = {
    'reqif': 'http://www.omg.org/spec/ReqIF/20110401/reqif.xsd',
    'xhtml': 'http://www.w3.org/1999/xhtml'
}

# --------------------------------------------------------------------
# Core lightweight ReqIF classes
# --------------------------------------------------------------------

class AttributeValue:
    """Represents a single ReqIF attribute value (STRING, XHTML, ENUM, etc.)."""
    def __init__(self, definition_ref=None, value=None):
        self.definition_ref = definition_ref
        self.value = value


class SpecObject:
    """Represents one <SPEC-OBJECT> in ReqIF."""
    def __init__(self, identifier=None, long_name=None, type_ref=None):
        self.identifier = identifier
        self.long_name = long_name
        self.type_ref = type_ref
        self.values = []

    def get_text_value(self):
        """Combine all string/xhtml values into one long text."""
        parts = []
        for val in self.values:
            if val.value:
                parts.append(val.value.strip())
        return "\n".join(parts)


# --------------------------------------------------------------------
# Main importer class
# --------------------------------------------------------------------

class ReqIFImporter:
    """
    Parses a ReqIF file into a simplified list of requirements:
        [{id, title, description, attributes...}, ...]
    """

    def __init__(self, file_path):
        self.file_path = file_path
        self.ns = dict(REQIF_NS)  # copy default namespaces

    def _detect_namespaces(self, root):
        """Auto-detect any additional namespaces used in the ReqIF file."""
        for k, v in root.attrib.items():
            if k.startswith("xmlns:"):
                prefix = k.split(":", 1)[1]
                self.ns[prefix] = v

    def _get_text_from_xhtml(self, elem):
        """Extracts readable text from XHTML blocks (ignoring markup)."""
        if elem is None:
            return ""
        return "".join(elem.itertext()).strip()

    def parse(self):
        tree = ET.parse(self.file_path)
        root = tree.getroot()
        self._detect_namespaces(root)

        spec_objects = []

        for so_elem in root.findall('.//reqif:SPEC-OBJECT', self.ns):
            so = SpecObject(
                identifier=so_elem.get('IDENTIFIER'),
                long_name=so_elem.get('LONG-NAME'),
                type_ref=so_elem.get('TYPE')
            )

            def append_attr(def_ref, value, attr_name=None):
                """Helper to append attribute values."""
                if value:
                    so.values.append(AttributeValue(def_ref, value))

            # -------------------------------
            # Extract STRING values
            # -------------------------------
            for attr_val in so_elem.findall('.//reqif:ATTRIBUTE-VALUE-STRING', self.ns):
                val = attr_val.find('reqif:THE-VALUE', self.ns)
                text_val = None
                if val is not None and val.text:
                    text_val = val.text.strip()
                elif 'THE-VALUE' in attr_val.attrib:  # EA-style attribute
                    text_val = attr_val.attrib['THE-VALUE'].strip()
                if text_val:
                    append_attr('STRING', text_val)

            # -------------------------------
            # Extract XHTML values
            # -------------------------------
            for attr_val in so_elem.findall('.//reqif:ATTRIBUTE-VALUE-XHTML', self.ns):
                xhtml_block = attr_val.find('.//xhtml:div', self.ns)
                if xhtml_block is not None:
                    text_content = self._get_text_from_xhtml(xhtml_block)
                    if text_content:
                        append_attr('XHTML', text_content)

            # -------------------------------
            # Extract ENUMERATION values with descriptions
            # -------------------------------
            for attr_val in so_elem.findall('.//reqif:ATTRIBUTE-VALUE-ENUMERATION', self.ns):
                enum_refs = []
                for v in attr_val.findall('.//reqif:ENUM-VALUE-REF', self.ns):
                    ref = v.get('REF') or (v.text.strip() if v.text else None)
                    if ref:
                        enum_desc = None
                        datatype_id = attr_val.find('.//reqif:ATTRIBUTE-DEFINITION-ENUMERATION-REF', self.ns)
                        if datatype_id is not None and datatype_id.text:
                            enum_value_elem = root.find(
                                f".//reqif:DATATYPE-DEFINITION-ENUMERATION[@IDENTIFIER='{datatype_id.text.strip()}']/reqif:SPECIFIED-VALUES/reqif:ENUM-VALUE[@IDENTIFIER='{ref}']",
                                self.ns
                            )
                            if enum_value_elem is not None and 'DESC' in enum_value_elem.attrib:
                                enum_desc = enum_value_elem.attrib['DESC'].strip()
                        if enum_desc:
                            enum_refs.append(f"{ref} ({enum_desc})")
                        else:
                            enum_refs.append(ref)
                if enum_refs:
                    append_attr('ENUM', ', '.join(enum_refs))

            # -------------------------------
            # Extract BOOLEAN, INTEGER, REAL, DATE
            # -------------------------------
            for val_type, tag in [('BOOLEAN', 'ATTRIBUTE-VALUE-BOOLEAN'),
                                  ('INTEGER', 'ATTRIBUTE-VALUE-INTEGER'),
                                  ('REAL', 'ATTRIBUTE-VALUE-REAL'),
                                  ('DATE', 'ATTRIBUTE-VALUE-DATE')]:
                for attr_val in so_elem.findall(f'.//reqif:{tag}', self.ns):
                    val = attr_val.find('reqif:THE-VALUE', self.ns)
                    if val is not None and val.text:
                        append_attr(val_type, val.text.strip())

            # -------------------------------
            # Extract custom fields (AD_TITLE, AD_DESC, AD_PRIORITY, etc.)
            # -------------------------------
            for attr_val in so_elem.findall('.//reqif:ATTRIBUTE-VALUE-STRING', self.ns):
                def_ref = attr_val.find('reqif:ATTRIBUTE-DEFINITION-STRING-REF', self.ns)
                the_val = attr_val.find('reqif:THE-VALUE', self.ns)
                if the_val is None and 'THE-VALUE' in attr_val.attrib:
                    the_val = type('Dummy', (), {})()  # safe dummy object
                    the_val.text = attr_val.attrib['THE-VALUE']

                if def_ref is not None and the_val is not None and the_val.text:
                    ref_name = def_ref.text.strip().upper()
                    if any(k in ref_name for k in ['TITLE', 'AD_TITLE', 'NAME']):
                        append_attr('TITLE', the_val.text.strip())
                    elif any(k in ref_name for k in ['DESC', 'DESCRIPTION', 'AD_DESC']):
                        append_attr('DESC', the_val.text.strip())
                    elif 'PRIORITY' in ref_name:
                        append_attr('PRIORITY', the_val.text.strip())
                    else:
                        append_attr(ref_name, the_val.text.strip())  # generic catch-all

            spec_objects.append(so)

        # ----------------------------------------------------------------
        # Convert to simplified requirement dicts
        # ----------------------------------------------------------------
        requirements = []
        for so in spec_objects:
            req_id = so.identifier or "UNKNOWN_ID"

            # Gather all text, enum, priority, and other values
            text_values = [v.value for v in so.values if v.definition_ref in ('STRING', 'XHTML')]
            enum_values = [v.value for v in so.values if v.definition_ref == 'ENUM']
            title_values = [v.value for v in so.values if v.definition_ref == 'TITLE']
            desc_values = [v.value for v in so.values if v.definition_ref == 'DESC']
            priority_values = [v.value for v in so.values if v.definition_ref == 'PRIORITY']
            other_values = [
                f"{v.definition_ref}: {v.value}"
                for v in so.values
                if v.definition_ref not in ('STRING', 'XHTML', 'TITLE', 'DESC', 'ENUM', 'PRIORITY')
            ]

            # Determine title
            title = (
                title_values[0]
                if title_values
                else (so.long_name or (text_values[0] if text_values else "Untitled Requirement"))
            )

            # Merge all possible description sources
            description_parts = []
            if desc_values:
                description_parts.extend(desc_values)
            if text_values:
                description_parts.extend(text_values)
            if enum_values:
                description_parts.append("Enum: " + ", ".join(enum_values))
            if priority_values:
                description_parts.append("Priority: " + ", ".join(priority_values))
            if other_values:
                description_parts.extend(other_values)

            description = "\n".join(part for part in description_parts if part).strip()
            if not description:
                description = "(No description found)"

            # Build final requirement record
            req_dict = {
                'id': req_id,
                'title': title.strip(),
                'description': description
            }

            # Add all other dynamic attributes
            for val in so.values:
                if val.definition_ref not in ('STRING', 'XHTML', 'TITLE', 'DESC'):
                    req_dict[val.definition_ref] = val.value

            requirements.append(req_dict)

        return requirements

