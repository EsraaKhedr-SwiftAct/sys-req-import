"""
reqif_importer.py
-----------------
Lightweight, dependency-free ReqIF parser.
Compatible with EA, DOORS, Polarion, Jama, and PTC ReqIF dialects.
Mimics the 'reqif' library interface but runs standalone.
"""

import xml.etree.ElementTree as ET

# Default ReqIF namespaces (auto-extended during parsing)
REQIF_NS = {
    'reqif': 'http://www.omg.org/spec/ReqIF/20110401/reqif.xsd',
    'xhtml': 'http://www.w3.org/1999/xhtml'
}

# --------------------------------------------------------------------
# Core lightweight ReqIF classes
# --------------------------------------------------------------------

class AttributeValue:
    """Represents a single ReqIF attribute value (STRING, XHTML, ENUM, etc.)."""
    def __init__(self, definition_ref=None, value=None, name=None):
        self.definition_ref = definition_ref
        self.value = value
        self.name = name or definition_ref


class SpecObject:
    """Represents one <SPEC-OBJECT> in ReqIF."""
    def __init__(self, identifier=None, long_name=None, type_ref=None):
        self.identifier = identifier
        self.long_name = long_name
        self.type_ref = type_ref
        self.values = []

    def get_text_value(self):
        """Combine all string/xhtml values into one long text."""
        parts = []
        for val in self.values:
            if val.value:
                parts.append(val.value.strip())
        return "\n".join(parts)


# --------------------------------------------------------------------
# Main importer class
# --------------------------------------------------------------------

class ReqIFImporter:
    """
    Parses a ReqIF file into a simplified list of requirements:
        [{id, title, description, attributes...}, ...]
    """

    def __init__(self, file_path):
        self.file_path = file_path
        self.ns = dict(REQIF_NS)  # copy default namespaces

    def _detect_namespaces(self, root):
        """Auto-detect any additional namespaces used in the ReqIF file."""
        for k, v in root.attrib.items():
            if k.startswith("xmlns:"):
                prefix = k.split(":", 1)[1]
                self.ns[prefix] = v

    def _get_text_from_xhtml(self, elem):
        """Extracts readable text from XHTML blocks (ignoring markup)."""
        if elem is None:
            return ""
        return "".join(elem.itertext()).strip()

    def parse(self):
        tree = ET.parse(self.file_path)
        root = tree.getroot()
        self._detect_namespaces(root)

        # ----------------------------------------------------------------
        # 🟢 Build Attribute Map (universal mapping for all tools)
        # ----------------------------------------------------------------
        attr_map = {}
        for attr_def in root.findall(".//reqif:SPEC-ATTRIBUTES/*", self.ns):
            attr_id = attr_def.get("IDENTIFIER")
            attr_name = attr_def.get("LONG-NAME") or attr_id
            attr_map[attr_id] = attr_name

        spec_objects = []

        for so_elem in root.findall('.//reqif:SPEC-OBJECT', self.ns):
            so = SpecObject(
                identifier=so_elem.get('IDENTIFIER'),
                long_name=so_elem.get('LONG-NAME'),
                type_ref=so_elem.get('TYPE')
            )

            def append_attr(def_ref, value, name_hint=None):
                """Helper to append attribute values."""
                if value:
                    so.values.append(AttributeValue(def_ref, value, name_hint))

            # -------------------------------
            # Extract STRING values
            # -------------------------------
            for attr_val in so_elem.findall('.//reqif:ATTRIBUTE-VALUE-STRING', self.ns):
                val = attr_val.find('reqif:THE-VALUE', self.ns)
                text_val = val.text.strip() if val is not None and val.text else None

                def_ref = attr_val.find('reqif:ATTRIBUTE-DEFINITION-STRING-REF', self.ns)
                ref_name = None
                if def_ref is not None and def_ref.text:
                    ref_name = attr_map.get(def_ref.text.strip(), def_ref.text.strip())

                if text_val:
                    append_attr('STRING', text_val, ref_name)

            # -------------------------------
            # Extract XHTML values
            # -------------------------------
            for attr_val in so_elem.findall('.//reqif:ATTRIBUTE-VALUE-XHTML', self.ns):
                xhtml_block = attr_val.find('.//xhtml:div', self.ns)
                if xhtml_block is not None:
                    text_content = self._get_text_from_xhtml(xhtml_block)
                    def_ref = attr_val.find('reqif:ATTRIBUTE-DEFINITION-XHTML-REF', self.ns)
                    ref_name = None
                    if def_ref is not None and def_ref.text:
                        ref_name = attr_map.get(def_ref.text.strip(), def_ref.text.strip())
                    if text_content:
                        append_attr('XHTML', text_content, ref_name)

            # -------------------------------
            # Extract ENUMERATION values
            # -------------------------------
            for attr_val in so_elem.findall('.//reqif:ATTRIBUTE-VALUE-ENUMERATION', self.ns):
                enum_refs = []
                def_ref = attr_val.find('reqif:ATTRIBUTE-DEFINITION-ENUMERATION-REF', self.ns)
                ref_name = None
                if def_ref is not None and def_ref.text:
                    ref_name = attr_map.get(def_ref.text.strip(), def_ref.text.strip())
                for v in attr_val.findall('.//reqif:ENUM-VALUE-REF', self.ns):
                    ref = v.get('REF') or (v.text.strip() if v.text else None)
                    if ref:
                        enum_refs.append(ref)
                if enum_refs:
                    append_attr('ENUM', ', '.join(enum_refs), ref_name)

            # -------------------------------
            # Extract BOOLEAN, INTEGER, REAL, DATE
            # -------------------------------
            for val_type, tag in [('BOOLEAN', 'ATTRIBUTE-VALUE-BOOLEAN'),
                                  ('INTEGER', 'ATTRIBUTE-VALUE-INTEGER'),
                                  ('REAL', 'ATTRIBUTE-VALUE-REAL'),
                                  ('DATE', 'ATTRIBUTE-VALUE-DATE')]:
                for attr_val in so_elem.findall(f'.//reqif:{tag}', self.ns):
                    val = attr_val.find('reqif:THE-VALUE', self.ns)
                    def_ref = attr_val.find(f'reqif:ATTRIBUTE-DEFINITION-{val_type}-REF', self.ns)
                    ref_name = None
                    if def_ref is not None and def_ref.text:
                        ref_name = attr_map.get(def_ref.text.strip(), def_ref.text.strip())
                    if val is not None and val.text:
                        append_attr(val_type, val.text.strip(), ref_name)

            spec_objects.append(so)

        # ----------------------------------------------------------------
        # Convert to simplified requirement dicts
        # ----------------------------------------------------------------
        requirements = []
        for so in spec_objects:
            req_id = so.identifier or "UNKNOWN_ID"

            # Extract title (try LONG-NAME or TITLE-like attribute)
            title = so.long_name or next((v.value for v in so.values
                                          if v.name and any(k in v.name.upper() for k in ['TITLE', 'NAME'])),
                                         "Untitled Requirement")

            # Extract description fields only (exclude title/priority/etc.)
            desc_values = [v.value for v in so.values if v.name and any(k in v.name.upper() for k in ['DESC', 'DESCRIPTION'])]
            text_values = [v.value for v in so.values if v.definition_ref in ('STRING', 'XHTML') and not v.name]
            description = "\n".join(desc_values + text_values).strip() or "(No description found)"

            # Collect remaining attributes (priority, status, etc.)
            attrs = {}
            for v in so.values:
                if v.name and v.name not in ('Description', 'Title', 'Name') and v.value and v.value not in description:
                    attrs[v.name] = v.value

            req_dict = {
                'id': req_id,
                'title': title.strip(),
                'description': description
            }
            req_dict.update(attrs)
            requirements.append(req_dict)

        return requirements

