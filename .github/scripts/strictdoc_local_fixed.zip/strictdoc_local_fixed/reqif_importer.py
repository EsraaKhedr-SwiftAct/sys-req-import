"""
reqif_importer.py
-----------------
Lightweight local ReqIF parser (compatible with multiple tools: DOORS, Polarion, Jama, PTC, etc.)
Mimics the 'reqif' library structure but runs standalone (no dependencies).
"""

import xml.etree.ElementTree as ET

REQIF_NS = {'reqif': 'http://www.omg.org/spec/ReqIF/20110401/reqif.xsd',
            'xhtml': 'http://www.w3.org/1999/xhtml'}

# --------------------------------------------------------------------
# Core lightweight ReqIF classes
# --------------------------------------------------------------------

class AttributeValue:
    """Represents a single ReqIF attribute value (STRING, XHTML, or ENUM)."""
    def __init__(self, definition_ref=None, value=None):
        self.definition_ref = definition_ref
        self.value = value

class SpecObject:
    """Represents one <SPEC-OBJECT> in ReqIF."""
    def __init__(self, identifier=None, long_name=None, type_ref=None):
        self.identifier = identifier
        self.long_name = long_name
        self.type_ref = type_ref
        self.values = []

    def get_text_value(self):
        """Combine all string/xhtml values into one long text."""
        parts = []
        for val in self.values:
            if val.value:
                parts.append(val.value.strip())
        return "\n".join(parts)

# --------------------------------------------------------------------
# Main importer class
# --------------------------------------------------------------------

class ReqIFImporter:
    """
    Parses a ReqIF file into a simplified list of requirements:
        [{id, title, description}, ...]
    """

    def __init__(self, file_path):
        self.file_path = file_path

    def parse(self):
        tree = ET.parse(self.file_path)
        root = tree.getroot()

        spec_objects = []
        for so_elem in root.findall('.//reqif:SPEC-OBJECT', REQIF_NS):
            so = SpecObject(
                identifier=so_elem.get('IDENTIFIER'),
                long_name=so_elem.get('LONG-NAME'),
                type_ref=so_elem.get('TYPE')
            )

            # Extract attribute values
            for attr_val in so_elem.findall('.//reqif:ATTRIBUTE-VALUE-STRING', REQIF_NS):
                val = attr_val.find('reqif:THE-VALUE', REQIF_NS)
                if val is not None and val.text:
                    so.values.append(AttributeValue('STRING', val.text))

            for attr_val in so_elem.findall('.//reqif:ATTRIBUTE-VALUE-XHTML', REQIF_NS):
                # Parse XHTML inner content (text only)
                xhtml_block = attr_val.find('.//xhtml:div', REQIF_NS)
                if xhtml_block is not None:
                    text_content = ''.join(xhtml_block.itertext()).strip()
                    so.values.append(AttributeValue('XHTML', text_content))

            for attr_val in so_elem.findall('.//reqif:ATTRIBUTE-VALUE-ENUMERATION', REQIF_NS):
                enum_refs = [v.get('REF') for v in attr_val.findall('.//reqif:ENUM-VALUE-REF', REQIF_NS)]
                if enum_refs:
                    so.values.append(AttributeValue('ENUM', ', '.join(enum_refs)))

            spec_objects.append(so)

        # ----------------------------------------------------------------
        # Convert to simplified requirement dicts
        # ----------------------------------------------------------------
        requirements = []
        for so in spec_objects:
            # Prefer long_name or first STRING value as title
            title = so.long_name or ""
            description = ""
            req_id = so.identifier or "UNKNOWN_ID"

            text_values = [v.value for v in so.values if v.definition_ref in ('STRING', 'XHTML')]
            enum_values = [v.value for v in so.values if v.definition_ref == 'ENUM']

            # Assign based on available content
            if not title and text_values:
                title = text_values[0]
                description = "\n".join(text_values[1:])
            elif len(text_values) > 1:
                description = "\n".join(text_values[1:])
            elif not description and text_values:
                description = text_values[0]

            if enum_values:
                description += "\n\nPriority/Enum: " + ", ".join(enum_values)

            requirements.append({
                'id': req_id,
                'title': title or "Untitled Requirement",
                'description': description.strip()
            })

        return requirements
