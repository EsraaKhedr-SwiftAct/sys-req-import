\
    import xml.etree.ElementTree as ET
    import os
    from collections import defaultdict

    class ReqIFImporter:
        def parse(self, path):
            if not os.path.exists(path):
                raise FileNotFoundError(path)
            with open(path, 'rb') as f:
                data = f.read()
            return self.parse_from_bytes(data)

        def parse_from_bytes(self, data):
            try:
                root = ET.fromstring(data)
            except ET.ParseError as e:
                raise ValueError(f'Failed to parse XML: {e}')

            def strip(tag):
                return tag.split('}', 1)[-1] if '}' in tag else tag

            spec_objects = root.findall('.//{*}SPEC-OBJECT') + root.findall('.//SPEC-OBJECT')
            reqs = []
            for so in spec_objects:
                identifier = ''
                title = ''
                description = ''
                attributes = {}
                for child in so.iter():
                    t = strip(child.tag).upper()
                    if t in ('IDENTIFIER','ID') and child.text:
                        if not identifier:
                            identifier = child.text.strip()
                    if t in ('LONG-NAME','TITLE','SHORT-NAME') and child.text:
                        if not title:
                            title = child.text.strip()
                    if t in ('DESC','DESCRIPTION') and child.text:
                        if not description:
                            description = child.text.strip()
                # attributes: collect ATTRIBUTE-VALUE-STRING THE-VALUE pairs
                for av in so.findall('.//{*}ATTRIBUTE-VALUE-STRING') + so.findall('.//ATTRIBUTE-VALUE-STRING'):
                    ref = None
                    val = ''
                    for ch in av:
                        tag = strip(ch.tag).upper()
                        if tag in ('THE-VALUE','THEVALUE','VALUE') and ch.text:
                            val = ch.text.strip()
                        if tag in ('DEFINITION','THE-ATTRIBUTE-DEFINITION-STRING','THE-ATTRIBUTE-DEFINITION') and ch.text:
                            ref = ch.text.strip()
                    if ref:
                        attributes[ref] = val
                reqs.append({'id': identifier, 'title': title, 'description': description, 'attributes': attributes})
            return reqs
